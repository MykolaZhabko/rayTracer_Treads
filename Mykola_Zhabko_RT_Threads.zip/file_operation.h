#include <stdio.h>
/* Output data as PPMfile */
void saveppm(char* filename, unsigned char* img, int width, int height);